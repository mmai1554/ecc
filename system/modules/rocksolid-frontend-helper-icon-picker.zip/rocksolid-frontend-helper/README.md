# RockSolid Frontend Helper Contao Extension

Install to */system/modules/rocksolid-frontend-helper/*

More information: 

* English: http://rocksolidthemes.com/en/contao/plugins/frontend-editing
* German: http://rocksolidthemes.com/de/contao/plugins/frontend-editing
