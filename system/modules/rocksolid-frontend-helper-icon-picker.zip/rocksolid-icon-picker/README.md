# RockSolid Icon Picker Contao Extension

Install to */system/modules/rocksolid-icon-picker/*
